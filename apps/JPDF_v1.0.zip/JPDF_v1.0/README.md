# JPDF v1.0 - PDF → 편집 가능 PPTX 변환기

PDF 슬라이드에서 텍스트를 OCR로 추출하고, 배경을 복원(inpainting)한 후 편집 가능한 PPTX를 생성합니다.

## 기능

- **OCR**: Google Cloud Vision API로 정확한 한글 텍스트 추출
- **Inpainting**: OpenCV로 텍스트 영역 배경 복원
- **PPTX 생성**: 깨끗한 배경 + 편집 가능한 텍스트 박스
- **스마트 병합**: 가까운 텍스트 블록 자동 병합

## 설치

```bash
pip install -r requirements.txt
```

## 설정

1. `.env.example`을 `.env.local`로 복사
2. Google Vision API 키 입력

```bash
cp .env.example .env.local
# .env.local 파일 편집하여 API 키 입력
```

## 사용법

```bash
# 기본 사용
python jpdf.py input.pdf

# 출력 파일 지정
python jpdf.py input.pdf -o output.pptx

# 텍스트 제거 없이 (원본 배경)
python jpdf.py input.pdf --no-inpaint

# 폰트 크기 고정
python jpdf.py input.pdf --font-size 20
```

## 옵션

| 옵션 | 설명 | 기본값 |
|------|------|--------|
| `-o, --output` | 출력 파일 경로 | `{입력파일}_편집가능.pptx` |
| `--api-key` | Google Vision API 키 | 환경변수 |
| `--no-inpaint` | 텍스트 제거 안함 | False |
| `--zoom` | 이미지 확대 비율 | 2.0 |
| `--padding` | 텍스트 영역 패딩 | 10 |
| `--inpaint-radius` | Inpainting 반경 | 7 |
| `--font-size` | 폰트 크기 고정 | 자동 |

## API 키 발급

1. Google Cloud Console 접속: https://console.cloud.google.com
2. 프로젝트 생성 또는 선택
3. Vision API 활성화
4. API 키 생성
5. `.env.local`에 키 입력

## 라이선스

MIT License
